﻿using System;
using System.Net.NetworkInformation;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;

namespace InterfaceTrafficWatch
{
    /// <summary>
    /// Network Interface Traffic Watch
    /// by Mohamed Mansour
    /// 
    /// Free to use under GPL open source license!
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// Timer Update (every 1 sec)
        /// </summary>
        private int timerUpdate = 500;

        private NetworkInterface nic;
        int max = 260;
        int maxup = 35;

        private Timer timer;
        ArrayList dataIn;
        ArrayList dataOut;
        Bitmap canvas;
        System.Drawing.SolidBrush drawBrushBG = new System.Drawing.SolidBrush(System.Drawing.Color.Gray);
        System.Drawing.SolidBrush drawBrushBlack = new System.Drawing.SolidBrush(System.Drawing.Color.Black);
        System.Drawing.SolidBrush drawBrushBlue = new System.Drawing.SolidBrush(System.Drawing.Color.DarkBlue);

        System.Drawing.SolidBrush drawBrushUP = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
        System.Drawing.SolidBrush drawBrushDL = new System.Drawing.SolidBrush(System.Drawing.Color.Green);
        System.Drawing.SolidBrush drawBrushYellow = new System.Drawing.SolidBrush(System.Drawing.Color.Yellow);
        Font font = new Font("Console", 6);
        double bytesSentLast = 0;
        double bytesreceivedLast = 0;

        /// <summary>
        /// Constructor
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            ReloadConfig();

            InitializeNetwork();
            InitializeTimer();
           
             canvas = new Bitmap (this.BackgroundImage);
             this.BackgroundImage = canvas;
             this.FormBorderStyle =  FormBorderStyle.None ;
             this.TransparencyKey = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(128)), ((System.Byte)(128)));
             this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
             dataIn = new ArrayList();
             dataOut = new ArrayList();
            
                     

        }

        public void ReloadConfig()
        {
            if (Application.UserAppDataRegistry.GetValue("X") != null && Application.UserAppDataRegistry.GetValue("Y") != null)
            {
                this.Left = (int)Application.UserAppDataRegistry.GetValue("X");


                this.Top = (int)Application.UserAppDataRegistry.GetValue("Y");
                //this.Location = new Point(, (int)Application.UserAppDataRegistry.GetValue("Y"));
             
            }
            if (Application.UserAppDataRegistry.GetValue("Minimized") != null)
            {
           //     Boolean b = (Boolean)Application.UserAppDataRegistry.GetValue("Minimized");
                //hidden = !b;
                //Minimalizuj_Click(null,null);
            }

            if (Application.UserAppDataRegistry.GetValue("MaxDL")!=null) max = (int)Application.UserAppDataRegistry.GetValue("MaxDL");
            if (Application.UserAppDataRegistry.GetValue("MaxUP") != null) maxup = (int)Application.UserAppDataRegistry.GetValue("MaxUP");
            if (Application.UserAppDataRegistry.GetValue("Timer") != null)
            {
                timerUpdate = (int)Application.UserAppDataRegistry.GetValue("Timer");
                if (timer != null)
                {
                    timer.Stop();
                    timer.Dispose();
                    InitializeTimer();
                }
            }
            if (Application.UserAppDataRegistry.GetValue("Interface") != null)
            {
                String nicName = (String)Application.UserAppDataRegistry.GetValue("Interface");
                NetworkInterface[] nicArr;
                nicArr = NetworkInterface.GetAllNetworkInterfaces();
                int ix = 0;
                // Add each interface name to the combo box
                for (int i = 0; i < nicArr.Length; i++)
                {
                    if (nicName != null && nicName == nicArr[i].Name)
                    {
                        nic = nicArr[i];
                    }
                }
            }
        }

        private void InitializeNetwork ()
        {
            nic = NetworkInterface.GetAllNetworkInterfaces()[0];
        }

      

        /// <summary>
        /// Initialize the Timer
        /// </summary>
        private void InitializeTimer()
        {
            timer = new Timer();
            timer.Interval = (int)timerUpdate;
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();
        }

 
        private void paintChart (System.Drawing.Graphics c, System.Drawing.SolidBrush color, int x,int y,  int samples, int height, ArrayList data)
        {
            if (data.Count > samples)
            {
                data.RemoveRange (0,data.Count-samples);
                data.TrimToSize ();
            }
            int max = 0;
            for (int i = 0 ; i < data.Count; i ++)
             if ((int)data[i] > max) max = (int)data[i];
            int margin = 0;
            int paintheight = height-margin;
            if (paintheight == 0) paintheight = height;
            if (max == 0) max = paintheight;
            double scale =  (double) paintheight / (double)max;

            for (int i = 2; i < data.Count; i++)
            {
                int lastY = (int)((int)data[i - 1] * (double)scale);
                int nowY =  (int)((int)data[i] * (double)scale); 

                c.DrawLine(new Pen(color), samples + x - i, y - lastY + paintheight, samples + x - i - 1, y - nowY + paintheight);
            }
        }

        private void paintCharts(String sent, String received)
        {
            System.Drawing.Graphics ImageCanvas = System.Drawing.Graphics.FromImage(canvas);
            
            ImageCanvas.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixelGridFit;
            ImageCanvas.FillRectangle(drawBrushBlack, 6, 6, this.Width - 12, this.Height - 12);
            
            //grid
            for (int i = 6; i < this.Width - 6; i += 4)
                for (int k = 6; k < this.Height - 6; k += 4)
                    canvas.SetPixel(i, k, Color.DarkBlue);

            ImageCanvas.DrawString(received + " in", font, drawBrushYellow, 12, 12);
            ImageCanvas.DrawString(sent + " out", font, drawBrushYellow, 12, this.Height / 2 + 5);
            ImageCanvas.DrawLine(new Pen(drawBrushBG), 6, this.Height / 2, this.Width - 6, this.Height / 2);
            paintChart(ImageCanvas, drawBrushDL, 10, 18, this.Width - 20, this.Height / 2 -20, dataIn);
            paintChart(ImageCanvas, drawBrushUP, 10, this.Height / 2 + 12, this.Width - 20, this.Height / 2 -20, dataOut);
            ImageCanvas.Dispose();            

        }

        private void paintTray(double bytesReceivedSpeed, double bytesSentSpeed)
        {
            Bitmap bmp = new Bitmap(16, 16);
            System.Drawing.Graphics ImageGraphics = System.Drawing.Graphics.FromImage(bmp);

            int min = 0;
            ImageGraphics.FillRectangle(drawBrushBG, 0, 0, 16, 16);
            ImageGraphics.DrawRectangle(new System.Drawing.Pen(drawBrushBlack), 0.0f, 0.0f, 15.0f, 15.0f);
            int scaleDl = ((int)bytesReceivedSpeed * 100 / max * 15) / 100;
            if (scaleDl > 15) scaleDl = 15;
            int scaleUp = ((int)bytesSentSpeed * 100 / maxup * 15) / 100;
            if (scaleUp > 15) scaleUp = 15;
            ImageGraphics.FillRectangle(drawBrushDL, 2, 16 - scaleDl, 5, scaleDl - 1);
            ImageGraphics.FillRectangle(drawBrushUP, 9, 16 - scaleUp, 5, scaleUp - 1);  
            ImageGraphics.Dispose();

            double inPercent = (bytesReceivedSpeed / (double)max) * 100.0;
            double outPercent = (bytesSentSpeed / (double)maxup) * 100.0;

            String text = "DL: " + Math.Round(bytesReceivedSpeed, 2) + " KB/s (" + Math.Round(inPercent, 2) + "%)\nUP: " + Math.Round(bytesSentSpeed, 2) + " KB/s (" + Math.Round(outPercent, 2) + "%)";
            notifyIcon1.Icon = Icon.FromHandle(bmp.GetHicon());
            notifyIcon1.Text = text;
        }

 
        /// <summary>
        /// Update GUI components for the network interfaces
        /// </summary>
        private void UpdateNetworkInterface()
        {
      
            IPv4InterfaceStatistics interfaceStats = nic.GetIPv4Statistics();
            double bytesSent = interfaceStats.BytesSent;
            double bytesReceived = interfaceStats.BytesReceived;
            if (bytesSentLast == 0) bytesSentLast = bytesSent;
            if (bytesreceivedLast == 0) bytesreceivedLast = bytesReceived;
            double bytesSentSpeed = (double)(bytesSent - bytesSentLast) / 1024 * (1000 / timerUpdate);
            double bytesReceivedSpeed = (double)(bytesReceived - bytesreceivedLast) / 1024 * (1000 / timerUpdate);


            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));

            String text = "";


            dataIn.Add((int)bytesReceivedSpeed);
                dataOut.Add((int)bytesSentSpeed);
                String sent  = Math.Round (bytesSentSpeed,2).ToString() + " KB/s";
                String received = Math.Round (bytesReceivedSpeed,2).ToString() + " KB/s";

                paintTray(bytesReceivedSpeed, bytesSentSpeed);
                paintCharts(sent, received);
                Invalidate();


                bytesSentLast = bytesSent;
                bytesreceivedLast = bytesReceived;

        }

        /// <summary>
        /// The Timer event for each Tick (second) to update the UI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void timer_Tick(object sender, EventArgs e)
        {
            UpdateNetworkInterface();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
        
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                Hide();

        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Minimalizuj_Click(sender, e);
        }

        private void MainForm_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            writeConfig();
            Application.Exit();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Setup  setup = new Setup ();
            writeConfig();
            setup.ShowDialog();
            
            ReloadConfig();

        }

        Boolean topMost = false;

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (topMost)
            {
                TopMost = false;
                toolStripMenuItem1.Font = new Font (toolStripMenuItem1.Font, FontStyle.Regular);
                  toolStripMenuItem1.Checked = false;
            }
            else
            {
                TopMost = true;
                toolStripMenuItem1.Font = new Font(toolStripMenuItem1.Font, FontStyle.Bold);
                toolStripMenuItem1.Checked = true;
                  
            }
            topMost = TopMost;

        }
        Point pos;
        Boolean hidden = false;
        private void toolStripMenuItem1_MouseDown(object sender, MouseEventArgs e)
        {
            pos = e.Location;
        }

        private void toolStripMenuItem1_MouseMove(object sender, MouseEventArgs e)
        {
           if (e.Button == MouseButtons.Left && pos!=null)
            {
                this.Left += (e.X - pos.X);

                
                this.Top += (e.Y - pos.Y);
            }
        }


    
        private void MainForm_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Minimalizuj_Click(object sender, EventArgs e)
        {

            if (hidden)
            {
                Show();
                hidden = false;
                Minimalizuj.Text = "Minimalizuj";
            }
            else
            {
                Hide();
                hidden = true;
                Minimalizuj.Text = "Pokaż";
            }
        }

        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            //Minimalizuj_Click(sender, e);
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            new AboutBox1().ShowDialog();
        }

        private void writeConfig()
        {
            Application.UserAppDataRegistry.SetValue("X", this.Left);
            Application.UserAppDataRegistry.SetValue("Y", this.Top);
            Application.UserAppDataRegistry.SetValue("Minimized", this.hidden);
        }

        private void MainForm_Leave(object sender, EventArgs e)
        {
         
        }



  

    }
}
